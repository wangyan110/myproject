<template>
    <div>
        404页面没找到！
    </div>
</template>

<script>
    export default {
    };
</script>

<style lang="less" scoped>
    div{
        font-size:20px;
        line-height: 50px;
        color:#555;
        max-width:900px;
        margin:auto;
        height:100%;
        background: url('../assets/404.jpg') no-repeat center;
    }
</style>
